package com.example.projects3java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projects3JavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Projects3JavaApplication.class, args);
    }

}
