package com.example.projects3java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projects3JavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
